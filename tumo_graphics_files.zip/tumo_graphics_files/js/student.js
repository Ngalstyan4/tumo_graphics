var Student = {
    // please fill in your name and NetID
    //  your NetID is the part of your email before @princeton.edu
    'name'  : 'Student Name/ՈՒսանողի Անունը',
    'tumoID' : 'tumoID',
};

Student.updateHTML = function( ) {
    var studentInfo = this.name + ' &lt;' + this.tumoID + '&gt;';
    document.getElementById('student').innerHTML = studentInfo;
}
